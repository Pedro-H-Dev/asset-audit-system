const API_URL = "/api/assets";

let allAssets = [];
let currentView = "overview";
let overviewMarkup = "";
let autoRefreshTimer = null;

const STATUS = {
    AVAILABLE: { label: "Disponível", css: "available" },
    IN_USE: { label: "Em uso", css: "assigned" },
    MAINTENANCE: { label: "Manutenção", css: "maintenance" }
};

/* =========================================================
   STARTUP
========================================================= */
document.addEventListener("DOMContentLoaded", () => {
    const content = document.querySelector(".content");
    overviewMarkup = content ? content.innerHTML : "";

    injectAppStyles();
    setupNavigation();
    setupGlobalButtons();
    setupKeyboardShortcuts();
    setupAutoRefresh();
    loadAssets();
});

/* =========================================================
   API
========================================================= */
async function apiFetch(url, options = {}) {
    const response = await fetch(url, options);
    if (!response.ok) {
        let message = `Erro HTTP ${response.status}`;
        try {
            const data = await response.json();
            message = data.message || data.error || message;
        } catch (_) {}
        throw new Error(message);
    }
    return response;
}

async function loadAssets() {
    try {
        const response = await apiFetch(API_URL);
        const data = await response.json();
        allAssets = Array.isArray(data) ? data : [];
        updateSystemStatus(true);

        if (currentView === "overview" || currentView === "assets") {
            renderOverviewAssets();
        }
        if (currentView === "employees") renderEmployeesView();
        if (currentView === "locations") renderLocationsView();
        if (currentView === "security") renderSecurityView();
        if (currentView === "audit") renderGlobalAuditView();
    } catch (error) {
        console.error(error);
        updateSystemStatus(false);
        showToast("Não foi possível conectar ao servidor.", "error");
    }
}

/* =========================================================
   OVERVIEW / INVENTORY
========================================================= */
function renderOverviewAssets() {
    const content = document.querySelector(".content");
    if (!content) return;

    // Rebuild the original dashboard when switching back to Overview/Assets.
    if (!document.getElementById("assetTable")) {
        content.innerHTML = overviewMarkup;
        translateStaticContent();
    }

    const assets = getFilteredAssets();
    renderAssets(assets);
    updateDashboardKPIs(allAssets);
    refreshActivity();
    setupSearch();
    setupDashboardButtons();
    setPageMeta(
        currentView === "assets" ? "Inventário de Ativos" : "Infraestrutura — Visão Geral",
        currentView === "assets"
            ? "Consulte, pesquise, altere o status e audite os ativos da organização."
            : "Monitore, gerencie e audite os ativos de TI da sua organização."
    );
}

function getFilteredAssets() {
    const input = document.getElementById("searchInput");
    const query = normalizeText(input?.value || "");
    if (!query) return allAssets;

    return allAssets.filter(asset => normalizeText([
        asset.name,
        asset.tagNumber,
        asset.category,
        asset.location,
        asset.status
    ].filter(Boolean).join(" ")).includes(query));
}

function renderAssets(assets) {
    const tableBody = document.getElementById("assetTable");
    if (!tableBody) return;

    tableBody.innerHTML = "";

    if (!assets.length) {
        tableBody.innerHTML = `
            <tr><td colspan="6">
                <div class="empty-state">
                    <i class="fa-solid fa-box-open"></i>
                    <strong>Nenhum ativo encontrado</strong>
                    <span>Tente outro termo ou cadastre um novo ativo.</span>
                </div>
            </td></tr>`;
        return;
    }

    assets.forEach(asset => {
        const status = normalizeStatus(asset.status);
        const info = STATUS[status] || STATUS.AVAILABLE;
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>
                <div class="asset-name">
                    <div class="asset-icon"><i class="fa-solid ${getAssetIcon(asset.name, asset.category)}"></i></div>
                    <div><strong>${escapeHTML(asset.name || "Sem nome")}</strong><span>${escapeHTML(asset.category || "TI")}</span></div>
                </div>
            </td>
            <td><span class="tag">${escapeHTML(asset.tagNumber || "-")}</span></td>
            <td>${escapeHTML(asset.category || "-")}</td>
            <td>${escapeHTML(asset.location || "-")}</td>
            <td><span class="status ${info.css}"><span class="status-dot-small"></span>${info.label}</span></td>
            <td>
                <div class="action-buttons">
                    <select class="asset-status-select" data-id="${asset.id}" title="Alterar status">
                        <option value="AVAILABLE" ${status === "AVAILABLE" ? "selected" : ""}>Disponível</option>
                        <option value="IN_USE" ${status === "IN_USE" ? "selected" : ""}>Em uso</option>
                        <option value="MAINTENANCE" ${status === "MAINTENANCE" ? "selected" : ""}>Manutenção</option>
                    </select>
                    <button class="table-button" data-action="audit" data-id="${asset.id}" title="Ver histórico">
                        <i class="fa-solid fa-clock-rotate-left"></i>
                    </button>
                    <button class="table-button delete" data-action="delete" data-id="${asset.id}" title="Excluir ativo">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            </td>`;
        tableBody.appendChild(row);
    });

    attachTableEvents();
}

function attachTableEvents() {
    const table = document.getElementById("assetTable");
    if (!table) return;

    table.querySelectorAll(".asset-status-select").forEach(select => {
        select.addEventListener("change", e => updateStatus(e.target.dataset.id, e.target.value));
    });
    table.querySelectorAll('[data-action="audit"]').forEach(button => {
        button.addEventListener("click", () => viewAuditTrail(button.dataset.id));
    });
    table.querySelectorAll('[data-action="delete"]').forEach(button => {
        button.addEventListener("click", () => {
            const asset = allAssets.find(a => String(a.id) === String(button.dataset.id));
            deleteAsset(button.dataset.id, asset?.name || "este ativo");
        });
    });
}

function updateDashboardKPIs(assets) {
    setText("totalAssets", assets.length);
    setText("availableAssets", assets.filter(a => normalizeStatus(a.status) === "AVAILABLE").length);
    setText("assignedAssets", assets.filter(a => normalizeStatus(a.status) === "IN_USE").length);
    setText("maintenanceAssets", assets.filter(a => normalizeStatus(a.status) === "MAINTENANCE").length);
}

function setupSearch() {
    const input = document.getElementById("searchInput");
    if (!input || input.dataset.bound === "true") return;
    input.dataset.bound = "true";
    input.addEventListener("input", () => renderAssets(getFilteredAssets()));
}

/* =========================================================
   CREATE / UPDATE / DELETE
========================================================= */
async function submitAsset(event) {
    event?.preventDefault();

    const tag = valueOf("assetTag");
    const name = valueOf("assetName");
    const category = valueOf("assetCategory");
    const location = valueOf("assetLocation");
    const status = valueOf("assetStatus") || "AVAILABLE";

    if (!tag || !name || !category || !location) {
        showToast("Preencha todos os campos obrigatórios.", "error");
        return false;
    }

    const button = document.querySelector("#assetModal .primary-button[type='submit']");
    if (button) button.disabled = true;

    try {
        const response = await apiFetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ tagNumber: tag, name, category, location })
        });

        let created = null;
        try { created = await response.json(); } catch (_) {}

        if (status !== "AVAILABLE" && created?.id != null) {
            await apiFetch(`${API_URL}/${created.id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, category, location, status })
            });
        }

        closeModal();
        resetAssetForm();
        await loadAssets();
        showToast(`Ativo "${name}" cadastrado com sucesso.`);
    } catch (error) {
        console.error(error);
        showToast(error.message || "Não foi possível cadastrar o ativo.", "error");
    } finally {
        if (button) button.disabled = false;
    }
    return false;
}

async function updateStatus(id, newStatus) {
    const asset = allAssets.find(a => String(a.id) === String(id));
    if (!asset) return;

    try {
        await apiFetch(`${API_URL}/${id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name: asset.name,
                category: asset.category,
                location: asset.location,
                status: newStatus
            })
        });
        await loadAssets();
        showToast(`Status alterado para ${formatStatus(newStatus)}.`);
    } catch (error) {
        showToast(error.message || "Não foi possível atualizar o status.", "error");
    }
}

async function deleteAsset(id, name) {
    if (!confirm(`Deseja realmente excluir "${name}"?\n\nEssa ação será registrada na trilha de auditoria.`)) return;

    try {
        await apiFetch(`${API_URL}/${id}`, { method: "DELETE" });
        await loadAssets();
        showToast(`Ativo "${name}" excluído com sucesso.`);
    } catch (error) {
        showToast(error.message || "Não foi possível excluir o ativo.", "error");
    }
}

/* =========================================================
   AUDIT
========================================================= */
async function getAssetLogs(asset) {
    try {
        const response = await fetch(`${API_URL}/${asset.id}/audit-logs`);
        if (!response.ok) return [];
        const logs = await response.json();
        return (Array.isArray(logs) ? logs : []).map(log => ({ ...log, asset }));
    } catch (_) {
        return [];
    }
}

async function viewAuditTrail(assetId) {
    const asset = allAssets.find(a => String(a.id) === String(assetId));
    if (!asset) return;

    try {
        const logs = await getAssetLogs(asset);
        openAuditModal(asset, logs);
    } catch (error) {
        showToast("Não foi possível carregar o histórico.", "error");
    }
}

function openAuditModal(asset, logs) {
    closeAuditModal();
    const modal = document.createElement("div");
    modal.id = "auditModalDynamic";
    modal.className = "app-modal-backdrop";

    const items = logs.length ? logs.map(log => `
        <div class="audit-item">
            <div class="audit-icon"><i class="fa-solid ${activityIcon(log.action)}"></i></div>
            <div class="audit-body">
                <div class="audit-top"><strong>${escapeHTML(formatAction(log.action))}</strong><span>${escapeHTML(formatDate(log.timestamp))}</span></div>
                <p>${escapeHTML(log.details || "Sem detalhes.")}</p>
            </div>
        </div>`).join("") : `
        <div class="empty-state audit-empty"><i class="fa-solid fa-clock-rotate-left"></i><strong>Nenhum registro encontrado</strong><span>Este ativo ainda não possui eventos de auditoria.</span></div>`;

    modal.innerHTML = `
        <div class="audit-modal">
            <div class="audit-modal-header">
                <div><span class="modal-eyebrow">TRILHA DE AUDITORIA</span><h2>${escapeHTML(asset.name || "Ativo")}</h2><p>${escapeHTML(asset.tagNumber || "")}</p></div>
                <button class="close-button" id="closeAuditButton" title="Fechar"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="audit-list">${items}</div>
        </div>`;

    document.body.appendChild(modal);
    modal.querySelector("#closeAuditButton").addEventListener("click", closeAuditModal);
    modal.addEventListener("click", e => { if (e.target === modal) closeAuditModal(); });
}

function closeAuditModal() {
    document.getElementById("auditModalDynamic")?.remove();
}

async function renderGlobalAuditView() {
    const content = document.querySelector(".content");
    if (!content) return;

    content.innerHTML = `
        <div class="module-grid">
            <section class="module-card module-wide">
                <div class="module-header"><div><span class="modal-eyebrow">COMPLIANCE</span><h2>Trilha de Auditoria</h2><p>Histórico real das ações registradas pelos ativos.</p></div><button class="secondary-button" id="refreshAuditButton"><i class="fa-solid fa-rotate"></i> Atualizar</button></div>
                <div id="globalAuditBody" class="global-audit-body"><div class="loading-state"><i class="fa-solid fa-spinner fa-spin"></i> Consultando histórico...</div></div>
            </section>
        </div>`;

    document.getElementById("refreshAuditButton")?.addEventListener("click", renderGlobalAuditView);
    const results = await Promise.all(allAssets.map(getAssetLogs));
    const logs = results.flat().sort((a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0));
    const body = document.getElementById("globalAuditBody");
    if (!body) return;

    body.innerHTML = logs.length ? logs.map(log => `
        <button class="global-audit-row audit-row-button" data-asset-id="${log.asset.id}">
            <div class="audit-icon"><i class="fa-solid ${activityIcon(log.action)}"></i></div>
            <div><strong>${escapeHTML(formatAction(log.action))}</strong><span>${escapeHTML(log.asset.tagNumber || "-")} · ${escapeHTML(log.asset.name || "")}</span></div>
            <p>${escapeHTML(log.details || "Sem detalhes.")}</p>
            <time>${escapeHTML(formatDate(log.timestamp))}</time>
        </button>`).join("") : `
        <div class="empty-state"><i class="fa-solid fa-clock-rotate-left"></i><strong>Nenhum evento encontrado</strong><span>As ações aparecerão aqui quando o backend registrar eventos.</span></div>`;

    body.querySelectorAll(".audit-row-button").forEach(button => {
        button.addEventListener("click", () => viewAuditTrail(button.dataset.assetId));
    });
}

/* =========================================================
   RECENT ACTIVITY
========================================================= */
async function refreshActivity() {
    const list = document.getElementById("activityList");
    if (!list) return;

    const results = await Promise.all(allAssets.map(getAssetLogs));
    const activities = results.flat().sort((a, b) => new Date(b.timestamp || 0) - new Date(a.timestamp || 0)).slice(0, 8);

    list.innerHTML = activities.length ? activities.map(item => `
        <button class="activity activity-button" data-asset-id="${item.asset.id}">
            <div class="activity-icon ${activityClass(item.action)}"><i class="fa-solid ${activityIcon(item.action)}"></i></div>
            <div class="activity-content"><strong>${escapeHTML(formatAction(item.action))} — ${escapeHTML(item.asset.tagNumber || "Ativo")}</strong><span>${escapeHTML(formatRelativeTime(item.timestamp))}</span></div>
            <i class="fa-solid fa-chevron-right activity-arrow"></i>
        </button>`).join("") : `
        <div class="empty-state compact"><i class="fa-solid fa-bolt"></i><span>Nenhuma atividade registrada.</span></div>`;

    list.querySelectorAll(".activity-button").forEach(button => {
        button.addEventListener("click", () => viewAuditTrail(button.dataset.assetId));
    });
}

/* =========================================================
   SIDEBAR VIEWS — REAL INTERACTION
========================================================= */
function setupNavigation() {
    document.querySelectorAll(".nav-item[data-view]").forEach(item => {
        item.addEventListener("click", event => {
            event.preventDefault();
            switchView(item.dataset.view);
        });
    });
}

function switchView(view) {
    currentView = view;
    document.querySelectorAll(".nav-item[data-view]").forEach(item => {
        item.classList.toggle("active", item.dataset.view === view);
    });

    const content = document.querySelector(".content");
    if (!content) return;

    if (view === "overview" || view === "assets") {
        content.innerHTML = overviewMarkup;
        translateStaticContent();
        renderOverviewAssets();
        if (view === "assets") {
            setTimeout(() => document.getElementById("assetTable")?.closest(".panel")?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
        }
        return;
    }

    if (view === "employees") {
        setPageMeta("Colaboradores", "Visão operacional dos ativos que estão atualmente em uso.");
        renderEmployeesView();
        return;
    }
    if (view === "locations") {
        setPageMeta("Localizações", "Distribuição real dos ativos por localização.");
        renderLocationsView();
        return;
    }
    if (view === "audit") {
        setPageMeta("Trilha de Auditoria", "Histórico consolidado das ações registradas nos ativos.");
        renderGlobalAuditView();
        return;
    }
    if (view === "security") {
        setPageMeta("Segurança", "Diagnóstico operacional da API e integridade do inventário.");
        renderSecurityView();
        return;
    }
    if (view === "settings") {
        setPageMeta("Configurações", "Preferências e controles da interface do AtivoOS.");
        renderSettingsView();
    }
}

function renderEmployeesView() {
    const content = document.querySelector(".content");
    const assigned = allAssets.filter(a => normalizeStatus(a.status) === "IN_USE");
    if (!content) return;

    content.innerHTML = `
        <div class="module-grid">
            <section class="module-card module-wide">
                <div class="module-header"><div><span class="modal-eyebrow">ALOCAÇÃO</span><h2>Colaboradores e ativos</h2><p>O backend atual não possui entidade de colaborador; esta tela usa os ativos em uso como visão de alocação.</p></div><div class="module-kpi">${assigned.length}</div></div>
                <div class="module-toolbar"><input id="employeeSearch" class="module-search" placeholder="Pesquisar ativo em uso..."><span class="setting-badge">Dados reais do inventário</span></div>
                <div class="module-table-wrap" id="employeesTableWrap"></div>
            </section>
        </div>`;

    const paint = () => {
        const q = normalizeText(document.getElementById("employeeSearch")?.value || "");
        const rows = assigned.filter(a => normalizeText([a.name,a.tagNumber,a.location,a.category].join(" ")).includes(q));
        document.getElementById("employeesTableWrap").innerHTML = rows.length ? `
            <table class="module-table"><thead><tr><th>Patrimônio</th><th>Ativo</th><th>Categoria</th><th>Localização</th><th>Ação</th></tr></thead><tbody>
            ${rows.map(a => `<tr><td><span class="tag">${escapeHTML(a.tagNumber)}</span></td><td>${escapeHTML(a.name)}</td><td>${escapeHTML(a.category)}</td><td>${escapeHTML(a.location)}</td><td><button class="secondary-button mini-audit" data-id="${a.id}"><i class="fa-solid fa-clock-rotate-left"></i> Histórico</button></td></tr>`).join("")}
            </tbody></table>` : `<div class="empty-state"><i class="fa-solid fa-users"></i><strong>Nenhum resultado</strong><span>Nenhum ativo em uso corresponde à pesquisa.</span></div>`;
        document.querySelectorAll(".mini-audit").forEach(b => b.addEventListener("click", () => viewAuditTrail(b.dataset.id)));
    };
    document.getElementById("employeeSearch").addEventListener("input", paint);
    paint();
}

function renderLocationsView() {
    const content = document.querySelector(".content");
    if (!content) return;
    const map = new Map();
    allAssets.forEach(asset => {
        const location = asset.location || "Sem localização";
        if (!map.has(location)) map.set(location, []);
        map.get(location).push(asset);
    });

    content.innerHTML = `
        <div class="module-grid">
            <section class="module-card module-wide">
                <div class="module-header"><div><span class="modal-eyebrow">DISTRIBUIÇÃO</span><h2>Localizações</h2><p>Clique em uma localização para filtrar o inventário por ela.</p></div><div class="module-kpi">${map.size}</div></div>
                <div class="location-grid">
                    ${[...map.entries()].map(([location, assets]) => `<button class="location-card location-button" data-location="${escapeHTML(location)}"><div class="location-icon"><i class="fa-solid fa-location-dot"></i></div><div class="location-info"><strong>${escapeHTML(location)}</strong><span>${assets.length} ativo${assets.length === 1 ? "" : "s"}</span></div><div class="location-count">${assets.length}</div></button>`).join("") || `<div class="empty-state"><i class="fa-solid fa-location-dot"></i><strong>Nenhuma localização</strong><span>Cadastre um ativo para começar.</span></div>`}
                </div>
            </section>
        </div>`;

    content.querySelectorAll(".location-button").forEach(button => {
        button.addEventListener("click", () => {
            switchView("assets");
            setTimeout(() => {
                const input = document.getElementById("searchInput");
                if (input) {
                    input.value = button.dataset.location;
                    input.dispatchEvent(new Event("input"));
                    input.focus();
                }
            }, 0);
        });
    });
}

function renderSecurityView() {
    const content = document.querySelector(".content");
    if (!content) return;
    const tags = allAssets.map(a => normalizeText(a.tagNumber)).filter(Boolean);
    const duplicates = tags.filter((tag, i) => tags.indexOf(tag) !== i);
    const duplicateCount = new Set(duplicates).size;

    content.innerHTML = `
        <div class="module-grid module-stats">
            <section class="module-card"><div class="security-icon success"><i class="fa-solid fa-server"></i></div><span class="modal-eyebrow">API</span><h2>API operacional</h2><p>Conexão com <code>/api/assets</code>.</p><strong class="security-value">ONLINE</strong><button class="secondary-button module-action" id="securityRefresh"><i class="fa-solid fa-rotate"></i> Testar novamente</button></section>
            <section class="module-card"><div class="security-icon info"><i class="fa-solid fa-database"></i></div><span class="modal-eyebrow">INTEGRIDADE</span><h2>Inventário</h2><p>Ativos carregados da API.</p><strong class="security-value">${allAssets.length}</strong></section>
            <section class="module-card"><div class="security-icon ${duplicateCount ? "danger" : "success"}"><i class="fa-solid fa-fingerprint"></i></div><span class="modal-eyebrow">VALIDAÇÃO</span><h2>Patrimônios duplicados</h2><p>Verificação local dos identificadores.</p><strong class="security-value">${duplicateCount}</strong></section>
        </div>`;

    document.getElementById("securityRefresh")?.addEventListener("click", async () => {
        await loadAssets();
        showToast("Diagnóstico concluído.");
    });
}

function renderSettingsView() {
    const content = document.querySelector(".content");
    if (!content) return;
    const auto = localStorage.getItem("ativoos_auto_refresh") !== "false";
    const notifications = localStorage.getItem("ativoos_notifications") !== "false";

    content.innerHTML = `
        <div class="module-grid">
            <section class="module-card module-wide">
                <div class="module-header"><div><span class="modal-eyebrow">PREFERÊNCIAS</span><h2>Configurações</h2><p>Estas opções realmente alteram o comportamento da interface neste navegador.</p></div></div>
                <div class="settings-list">
                    <div class="setting-row"><div><strong>Atualização automática</strong><span>Atualiza o inventário a cada 30 segundos.</span></div><label class="switch"><input type="checkbox" id="autoRefreshToggle" ${auto ? "checked" : ""}><span></span></label></div>
                    <div class="setting-row"><div><strong>Notificações</strong><span>Exibe mensagens de sucesso e alerta na interface.</span></div><label class="switch"><input type="checkbox" id="notificationToggle" ${notifications ? "checked" : ""}><span></span></label></div>
                    <div class="setting-row"><div><strong>Atalho de pesquisa</strong><span>Use Ctrl + K para focar a busca.</span></div><span class="setting-badge">Ativo</span></div>
                    <div class="setting-row"><div><strong>Conexão</strong><span>Endpoint atual: ${API_URL}</span></div><button class="secondary-button" id="settingsRefresh"><i class="fa-solid fa-rotate"></i> Testar conexão</button></div>
                    <div class="setting-row"><div><strong>Restaurar preferências</strong><span>Volta as opções locais para o padrão.</span></div><button class="danger-outline" id="resetSettings"><i class="fa-solid fa-arrow-rotate-left"></i> Restaurar</button></div>
                </div>
            </section>
        </div>`;

    document.getElementById("autoRefreshToggle").addEventListener("change", e => {
        localStorage.setItem("ativoos_auto_refresh", e.target.checked);
        setupAutoRefresh();
        showToast(e.target.checked ? "Atualização automática ativada." : "Atualização automática desativada.");
    });
    document.getElementById("notificationToggle").addEventListener("change", e => {
        localStorage.setItem("ativoos_notifications", e.target.checked);
        showToast(e.target.checked ? "Notificações ativadas." : "Notificações desativadas.");
    });
    document.getElementById("settingsRefresh").addEventListener("click", async () => {
        await loadAssets();
        showToast("Conexão com a API verificada.");
    });
    document.getElementById("resetSettings").addEventListener("click", () => {
        localStorage.removeItem("ativoos_auto_refresh");
        localStorage.removeItem("ativoos_notifications");
        renderSettingsView();
        setupAutoRefresh();
        showToast("Preferências restauradas.");
    });
}

/* =========================================================
   GLOBAL BUTTONS / MODAL
========================================================= */
function setupGlobalButtons() {
    document.getElementById("notificationButton")?.addEventListener("click", () => {
        if (localStorage.getItem("ativoos_notifications") === "false") return;
        if (currentView !== "overview") switchView("overview");
        setTimeout(() => document.getElementById("activityList")?.scrollIntoView({ behavior: "smooth", block: "center" }), 50);
        showToast("Atividade recente aberta.");
    });

    document.getElementById("headerSearchButton")?.addEventListener("click", focusSearch);
    document.querySelectorAll('.primary-button').forEach(button => {
        if (button.textContent.includes("Novo Ativo")) button.addEventListener("click", openModal);
    });

    bindModal();
}

function setupDashboardButtons() {
    document.getElementById("notificationButton")?.replaceWith(document.getElementById("notificationButton")?.cloneNode(true));
    // Header is outside .content and keeps its listener from startup; only rebind if necessary.
    document.getElementById("notificationButton")?.addEventListener("click", () => {
        if (currentView !== "overview") switchView("overview");
        setTimeout(() => document.getElementById("activityList")?.scrollIntoView({ behavior: "smooth", block: "center" }), 50);
        showToast("Atividade recente aberta.");
    });
    document.getElementById("headerSearchButton")?.addEventListener("click", focusSearch);
    bindModal();
}

function bindModal() {
    const modal = document.getElementById("assetModal");
    if (!modal || modal.dataset.bound === "true") return;
    modal.dataset.bound = "true";
    modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
}

function openModal() {
    const modal = document.getElementById("assetModal");
    if (!modal) return;
    modal.classList.add("active");
    document.getElementById("assetTag")?.focus();
}

function closeModal() {
    document.getElementById("assetModal")?.classList.remove("active");
}

function resetAssetForm() {
    document.querySelector("#assetModal form")?.reset();
}

/* =========================================================
   KEYBOARD / AUTO REFRESH
========================================================= */
function setupKeyboardShortcuts() {
    document.addEventListener("keydown", event => {
        if (event.key === "Escape") {
            closeModal();
            closeAuditModal();
        }
        if (event.ctrlKey && event.key.toLowerCase() === "k") {
            event.preventDefault();
            focusSearch();
        }
    });
}

function focusSearch() {
    if (currentView !== "overview" && currentView !== "assets") switchView("assets");
    setTimeout(() => {
        const input = document.getElementById("searchInput");
        if (input) { input.focus(); input.select(); }
    }, 0);
}

function setupAutoRefresh() {
    clearInterval(autoRefreshTimer);
    if (localStorage.getItem("ativoos_auto_refresh") === "false") return;
    autoRefreshTimer = setInterval(() => {
        if (document.visibilityState === "visible") loadAssets();
    }, 30000);
}

/* =========================================================
   UI HELPERS
========================================================= */
function setPageMeta(title, description) {
    const h1 = document.querySelector(".page-header h1");
    const desc = document.querySelector(".page-description");
    if (h1) h1.textContent = title;
    if (desc) desc.textContent = description;
}

function translateStaticContent() {
    document.querySelectorAll("[data-translate]").forEach(el => { el.textContent = el.dataset.translate; });
}

function updateSystemStatus(online) {
    document.querySelectorAll(".system-status").forEach(el => {
        el.querySelector(".system-status-title")?.replaceChildren(
            Object.assign(document.createElement("span"), { className: "status-dot" }),
            document.createTextNode(online ? "Sistema operacional" : "Sistema indisponível")
        );
        const p = el.querySelector("p");
        if (p) p.textContent = online ? "Última sincronização: agora" : "Verifique a conexão com a API";
    });
}

function normalizeStatus(status) { return String(status || "AVAILABLE").toUpperCase().trim(); }
function formatStatus(status) { return STATUS[normalizeStatus(status)]?.label || "Disponível"; }
function formatAction(action) {
    const a = String(action || "AÇÃO").toUpperCase();
    return ({ CREATE: "Ativo criado", CREATED: "Ativo criado", UPDATE: "Ativo atualizado", UPDATED: "Ativo atualizado", DELETE: "Ativo excluído", DELETED: "Ativo excluído", STATUS_CHANGE: "Status alterado", STATUS_UPDATED: "Status alterado" })[a] || a.replaceAll("_", " ");
}
function activityIcon(action) {
    const a = String(action || "").toUpperCase();
    if (a.includes("DELETE")) return "fa-trash";
    if (a.includes("CREATE")) return "fa-plus";
    if (a.includes("STATUS")) return "fa-arrows-rotate";
    return "fa-pen";
}
function activityClass(action) {
    const a = String(action || "").toUpperCase();
    if (a.includes("DELETE")) return "edit";
    if (a.includes("CREATE")) return "add";
    return "edit";
}
function getAssetIcon(name, category) {
    const value = `${name || ""} ${category || ""}`.toLowerCase();
    if (value.includes("monitor") || value.includes("display")) return "fa-display";
    if (value.includes("notebook") || value.includes("laptop")) return "fa-laptop";
    if (value.includes("pc") || value.includes("computer") || value.includes("desktop")) return "fa-computer";
    if (value.includes("router") || value.includes("switch") || value.includes("rede")) return "fa-network-wired";
    if (value.includes("printer") || value.includes("impressora")) return "fa-print";
    if (value.includes("server") || value.includes("servidor")) return "fa-server";
    return "fa-box";
}
function valueOf(id) { return document.getElementById(id)?.value?.trim() || ""; }
function setText(id, value) { const el = document.getElementById(id); if (el) el.textContent = value; }
function formatDate(timestamp) { if (!timestamp) return "Data desconhecida"; return new Date(timestamp).toLocaleString("pt-BR", { dateStyle: "medium", timeStyle: "short" }); }
function formatRelativeTime(timestamp) {
    if (!timestamp) return "agora";
    const diff = Math.max(0, Date.now() - new Date(timestamp).getTime());
    const min = Math.floor(diff / 60000);
    if (min < 1) return "agora";
    if (min < 60) return `há ${min} min`;
    const h = Math.floor(min / 60);
    if (h < 24) return `há ${h} h`;
    return `há ${Math.floor(h / 24)} d`;
}
function normalizeText(value) { return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim(); }
function escapeHTML(value) { return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;"); }

function showToast(message, type = "success") {
    if (type !== "success" && localStorage.getItem("ativoos_notifications") === "false") return;
    const container = document.getElementById("toastContainer") || createToastContainer();
    const toast = document.createElement("div");
    toast.className = `toast ${type === "error" ? "toast-error" : ""}`;
    toast.innerHTML = `<i class="fa-solid ${type === "error" ? "fa-circle-exclamation" : "fa-circle-check"}"></i><span>${escapeHTML(message)}</span>`;
    container.appendChild(toast);
    setTimeout(() => { toast.style.opacity = "0"; toast.style.transform = "translateY(8px)"; setTimeout(() => toast.remove(), 220); }, 3500);
}
function createToastContainer() {
    const el = document.createElement("div");
    el.id = "toastContainer";
    el.className = "toast-container";
    document.body.appendChild(el);
    return el;
}

function injectAppStyles() {
    if (document.getElementById("appFunctionalStyles")) return;
    const style = document.createElement("style");
    style.id = "appFunctionalStyles";
    style.textContent = `
        .activity-button,.location-button,.audit-row-button{font:inherit;text-align:left;border:0;color:inherit;cursor:pointer}
        .activity-button{width:100%;display:flex;align-items:center;gap:12px;background:transparent;border-bottom:1px solid rgba(255,255,255,.06);padding:12px 0}
        .activity-button:hover{background:rgba(129,140,248,.05)}
        .activity-arrow{margin-left:auto;color:#566077;font-size:10px}
        .location-button{width:100%}
        .location-button:hover{border-color:rgba(129,140,248,.35);transform:translateY(-1px)}
        .audit-row-button{width:100%;display:grid;background:transparent;color:inherit;border-bottom:1px solid rgba(255,255,255,.06);padding:0;cursor:pointer}
        .audit-row-button:hover{background:rgba(129,140,248,.05)}
        .module-toolbar{display:flex;align-items:center;gap:12px;margin-bottom:16px}
        .module-search{width:min(360px,100%);background:#0b1018;border:1px solid rgba(255,255,255,.1);color:#e7ebf4;border-radius:9px;padding:10px 12px;outline:none}
        .module-search:focus{border-color:#6366f1}
        .module-action{margin-top:15px}
        .danger-outline{border:1px solid rgba(239,68,68,.35);background:transparent;color:#fb7185;border-radius:8px;padding:9px 12px;cursor:pointer}
        .switch{position:relative;width:42px;height:24px;display:inline-block}.switch input{display:none}.switch span{position:absolute;inset:0;background:#252d3b;border-radius:20px;cursor:pointer;transition:.2s}.switch span:before{content:"";position:absolute;width:18px;height:18px;left:3px;top:3px;border-radius:50%;background:#aab3c3;transition:.2s}.switch input:checked+span{background:#4f46e5}.switch input:checked+span:before{transform:translateX(18px);background:#fff}
        .mini-audit{padding:7px 10px!important;font-size:9px!important}
        @media(max-width:900px){.module-grid{grid-template-columns:1fr}.global-audit-row{grid-template-columns:34px 1fr}.global-audit-row p,.global-audit-row time{grid-column:2}}
    `;
    document.head.appendChild(style);
}
